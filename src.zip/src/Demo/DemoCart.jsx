import { Box, Flex, Heading, Text, Button, Center, Grid, GridItem } from '@chakra-ui/react';
import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { useContext } from 'react';
import { AuthContext } from '../Authenticate/AuthContext';
import PaymentDetails from '../Payment/PaymentDetails';
import CartCard from './CartCard';

function DemoCart() {

    const { cartData, deleteCartItem, IncreaseCartQty, DecreaseCartQty, cartQty } = useContext(AuthContext)


    // ################ for cart total ############ 
    // for (let el of cartData) {
    //     console.log(el.price.split("").filter((el) => el !== ",").join(""));
    //    agar number me comma laga ho to 
    // }

    const TotalPrice = cartData.reduce((acc, el) => (acc + Number(el.price.split("").filter((el) => el !== ",").join(""))), 0)

    const fPrice = TotalPrice.toFixed(2);



    const FullPrice = cartData.reduce((acc, el) => (acc + Number(el.Fprice.split("").filter((el) => el !== ",").join(""))), 0)
    const PwithoutDis = FullPrice.toFixed(2);




    return (
        <div></div>

        // <Flex gap={8} w="70%" margin="auto" marginTop={10}>
        //     <Box>
        //         <Heading marginBottom={10}>Order Summary</Heading>
        //         <Text>PRODUCTS</Text>
        //         {cartData.length !== 0 ? <Box>
        //             {cartData.map((item) => <Box borderBottom="1px solid gray">
        //                 {data.data !== undefined && <Grid templateColumns='repeat(7, 1fr)'>
        //                     <GridItem p={5} colSpan={1}>
        //                         <Center>
        //                             <img width="50px" src={data.data.url} alt="" />
        //                         </Center>
        //                     </GridItem>
        //                     <GridItem padding={5} colSpan={3}>
        //                         <Text fontSize={18}>{data.data.title}</Text>
        //                         <Text fontSize="xs" as="i">{data.data.mkt}</Text>
        //                         <Text h={10} marginTop={5} color="#f50271" fontSize="lg">RS {data.data.price} <span style={{ color: "gray", fontSize: "14px", fontWeight: "400", textDecoration: "line-through" }}>{data.data.Fprice}</span></Text>


        //                         <Text fontSize="sm" color="gray">Delivery between Jul 23 6PM-Jul 24 10PM</Text>
        //                     </GridItem>
        //                     <GridItem padding={5} colSpan={3}>
        //                         <Flex gap={18} h="full" alignItems="flex-end">
        //                             <Button onClick={() => data.deleteCartItem(data.data.id)}>Remove</Button>

        //                             <Flex>
        //                                 <Button onClick={() => DecreaseCartQty(data.data.id)} fontSize="25px">-</Button>

        //                                 <Center fontSize={20} fontWeight="bold" w={10}>{cartQty}</Center>

        //                                 <Button onClick={() => IncreaseCartQty(data.data.id)} fontSize="25px">+</Button>
        //                             </Flex>

        //                         </Flex>
        //                     </GridItem>
        //                 </Grid>}
        //             </Box>
        //             )}
        //         </Box> : null}
        //     </Box>
        //     {/* <PaymentDetails price={fPrice} total={PwithoutDis} /> */}
        // </Flex>
    )
}

export default DemoCart
